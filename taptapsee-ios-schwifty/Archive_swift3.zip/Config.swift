//  Converted with Swiftify v1.0.6242 - https://objectivec2swift.com/
//
//  Config.swift
//  TapTapSee
//
//  Copyright (c) 2016 CamFind Inc. All rights reserved.
//
let STR_DATADIR = "taptapsee"
let STR_DATAFILE = "data.plist"
let STR_DATAFILE_VER = "1.1"
let STR_KEY_VERSION = "version"
let CLOUDSIGHT_KEY = "eaE7vaJbrPW9PdBc7ygBWQ"
let CLOUDSIGHT_SECRET = "Kb0DJxKp58bdE9KCueGIXw"
let THUMB_WIDTH = 40
let THUMB_HEIGHT = 40
let MAX_QUERY_COUNT = 3
let DEFAULT_USER_ACCEPTED_OFFENSIVE_IMAGE_POLICY = "user_accepted_offensive_image_policy"
let DEFAULT_FOCUS_LOCK_SOUND_KEY = "focus_lock_sound_enabled"
let DEFAULT_FLASH_KEY = "flash_enabled"
