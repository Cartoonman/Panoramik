//  Converted with Swiftify v1.0.6242 - https://objectivec2swift.com/
//
//  main.swift
//  TapTapSee
//
//  Copyright (c) 2016 CamFind Inc. All rights reserved.
//
import UIKit
func main(argc: Int, argv: [CChar]) -> Int {
            return UIApplicationMain(argc, argv, nil, NSStringFromClass(AppDelegate.self))

}